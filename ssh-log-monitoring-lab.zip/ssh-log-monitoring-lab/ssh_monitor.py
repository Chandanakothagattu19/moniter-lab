#!/usr/bin/env python3
"""
SSH Log Monitor
---------------
Reads a Linux authentication log (on Rocky Linux: /var/log/secure) and looks for
signs of a password-guessing (brute force) attack on SSH.

It reports:
  1. Source IPs with many failed logins in a short time (possible brute force)
  2. Any successful login that came right after many failures (possible break-in)
  3. Which usernames were tried and which IPs failed the most

Usage:
    python3 ssh_monitor.py sample_logs/auth_sample.log
    sudo python3 ssh_monitor.py /var/log/secure --threshold 5 --window 5
"""

import argparse
import re
from collections import defaultdict
from datetime import datetime, timedelta

# One syslog line looks like:
# Nov 25 10:15:32 rocky sshd[1234]: Failed password for invalid user admin from 203.0.113.45 port 40222 ssh2
LINE = re.compile(
    r"^(?P<month>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s+(?P<time>\d{2}:\d{2}:\d{2})\s+\S+\s+sshd\[\d+\]:\s+(?P<msg>.*)$"
)
IP = r"(?P<ip>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})"
FAILED = re.compile(r"Failed password for (?:invalid user )?(?P<user>\S+) from " + IP)
INVALID = re.compile(r"Invalid user (?P<user>\S+) from " + IP)
ACCEPTED = re.compile(r"Accepted (?:password|publickey) for (?P<user>\S+) from " + IP)


def parse_line(line, year):
    """Turn one log line into an event dictionary, or None if it is not a login event."""
    match = LINE.match(line.strip())
    if not match:
        return None
    try:
        when = datetime.strptime(
            f"{year} {match['month']} {match['day']} {match['time']}", "%Y %b %d %H:%M:%S"
        )
    except ValueError:
        return None

    msg = match["msg"]
    for kind, pattern in (("failed", FAILED), ("invalid_user", INVALID), ("accepted", ACCEPTED)):
        found = pattern.search(msg)
        if found:
            return {"time": when, "kind": kind, "user": found["user"], "ip": found["ip"]}
    return None


def parse_file(path, year):
    """Read the whole log file and return a list of events in time order."""
    events = []
    with open(path, "r", errors="replace") as handle:
        for line in handle:
            event = parse_line(line, year)
            if event:
                events.append(event)
    events.sort(key=lambda e: e["time"])
    return events


def find_brute_force(events, threshold, window_minutes):
    """Return {ip: details} for IPs with >= threshold failed logins inside the time window."""
    window = timedelta(minutes=window_minutes)
    times_by_ip = defaultdict(list)
    for e in events:
        if e["kind"] == "failed":
            times_by_ip[e["ip"]].append(e["time"])

    flagged = {}
    for ip, times in times_by_ip.items():
        start = 0
        best = 0
        best_span = (times[0], times[0])
        for end in range(len(times)):
            while times[end] - times[start] > window:  # slide the window forward
                start += 1
            count = end - start + 1
            if count > best:
                best, best_span = count, (times[start], times[end])
        if best >= threshold:
            flagged[ip] = {"max_in_window": best, "first": best_span[0], "last": best_span[1],
                           "total_failures": len(times)}
    return flagged


def find_success_after_failures(events, threshold, window_minutes):
    """Return successful logins that happened right after many failures from the same IP."""
    window = timedelta(minutes=window_minutes)
    alerts = []
    for e in events:
        if e["kind"] != "accepted":
            continue
        recent_failures = [
            f for f in events
            if f["kind"] == "failed" and f["ip"] == e["ip"]
            and timedelta(0) <= e["time"] - f["time"] <= window
        ]
        if len(recent_failures) >= threshold:
            alerts.append({"time": e["time"], "user": e["user"], "ip": e["ip"],
                           "failures_before": len(recent_failures)})
    return alerts


def build_report(events, threshold, window_minutes):
    """Create the text report."""
    failed = [e for e in events if e["kind"] == "failed"]
    accepted = [e for e in events if e["kind"] == "accepted"]
    brute = find_brute_force(events, threshold, window_minutes)
    breakins = find_success_after_failures(events, threshold, window_minutes)

    fails_by_ip = defaultdict(int)
    users_tried = defaultdict(int)
    for e in failed:
        fails_by_ip[e["ip"]] += 1
    for e in events:
        if e["kind"] in ("failed", "invalid_user"):
            users_tried[e["user"]] += 1

    lines = []
    lines.append("SSH LOG MONITOR REPORT")
    lines.append("=" * 60)
    lines.append(f"Rule: {threshold}+ failed logins from one IP within {window_minutes} minutes")
    lines.append(f"Failed logins: {len(failed)} | Successful logins: {len(accepted)}")
    lines.append("")

    lines.append("[ALERT] Possible brute force attacks")
    if brute:
        for ip, d in sorted(brute.items(), key=lambda x: -x[1]["max_in_window"]):
            lines.append(f"  {ip}: {d['max_in_window']} failures in the window "
                         f"({d['first']:%H:%M:%S} to {d['last']:%H:%M:%S}), "
                         f"{d['total_failures']} failures in total")
    else:
        lines.append("  None found")
    lines.append("")

    lines.append("[CRITICAL] Successful login right after repeated failures")
    if breakins:
        for a in breakins:
            lines.append(f"  {a['time']:%H:%M:%S} user '{a['user']}' logged in from {a['ip']} "
                         f"after {a['failures_before']} failures. Check this account now.")
    else:
        lines.append("  None found")
    lines.append("")

    lines.append("Top source IPs by failed logins")
    for ip, count in sorted(fails_by_ip.items(), key=lambda x: -x[1])[:5]:
        lines.append(f"  {ip}: {count}")
    lines.append("")

    lines.append("Usernames tried")
    for user, count in sorted(users_tried.items(), key=lambda x: -x[1])[:8]:
        lines.append(f"  {user}: {count}")
    lines.append("")

    lines.append("Suggested actions: block the flagged IPs, turn off password login (use SSH keys),")
    lines.append("and reset the password of any account listed under CRITICAL.")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Detect SSH brute force attempts in a Linux auth log.")
    parser.add_argument("logfile", help="path to the log file, e.g. /var/log/secure")
    parser.add_argument("--threshold", type=int, default=5, help="failures needed to raise an alert (default 5)")
    parser.add_argument("--window", type=int, default=5, help="time window in minutes (default 5)")
    parser.add_argument("--year", type=int, default=datetime.now().year, help="year of the log (syslog has no year)")
    parser.add_argument("--output", help="also save the report to this file")
    args = parser.parse_args()

    events = parse_file(args.logfile, args.year)
    report = build_report(events, args.threshold, args.window)
    print(report)
    if args.output:
        with open(args.output, "w") as out:
            out.write(report + "\n")


if __name__ == "__main__":
    main()
