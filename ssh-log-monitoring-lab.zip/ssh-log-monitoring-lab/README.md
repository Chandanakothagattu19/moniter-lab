# SSH Log Monitoring Lab (Python + Rocky Linux)

A small Python tool that reads a Linux login log and catches people trying to guess SSH passwords. It is a mini version of what a SIEM tool like Splunk or Wazuh does: collect logs, apply a rule, raise an alert.

## What it does
- Reads the SSH login log (`/var/log/secure` on Rocky Linux)
- **Alert:** an IP with 5 or more failed logins within 5 minutes (possible brute force)
- **Critical:** a successful login that comes right after many failures from the same IP (possible break-in)
- Shows the top attacking IPs and the usernames that were tried
- Both limits can be changed (`--threshold` and `--window`)

## Project files
```
ssh_monitor.py            the monitoring tool
generate_sample_log.py    makes a sample log for testing
sample_logs/              the sample log (made-up data)
reports/sample_report.txt output of the tool on the sample log
tests/                    8 unit tests
```

## How to run

You only need Python 3. Check it on Rocky Linux with `python3 --version` (install with `sudo dnf install python3` if missing).

Try it on the sample log:
```
python3 ssh_monitor.py sample_logs/auth_sample.log --year 2026
```

Run the tests:
```
python3 -m unittest discover -s tests -v
```

Run it on a real Linux machine (needs sudo to read the log):
```
sudo python3 ssh_monitor.py /var/log/secure
```

Change the rule and save the report:
```
python3 ssh_monitor.py sample_logs/auth_sample.log --year 2026 --threshold 3 --window 10 --output reports/my_report.txt
```

## Example output (from the sample log)
```
SSH LOG MONITOR REPORT
============================================================
Rule: 5+ failed logins from one IP within 5 minutes
Failed logins: 26 | Successful logins: 5

[ALERT] Possible brute force attacks
  203.0.113.45: 14 failures in the window (10:00:00 to 10:01:57), 14 failures in total
  203.0.113.99: 7 failures in the window (11:00:00 to 11:00:36), 7 failures in total

[CRITICAL] Successful login right after repeated failures
  11:00:52 user 'support' logged in from 203.0.113.99 after 7 failures. Check this account now.

Top source IPs by failed logins
  203.0.113.45: 14
  203.0.113.99: 7
  198.51.100.7: 3
  192.168.1.22: 2
```
Notice that `192.168.1.22` (a user who mistyped a password twice) and `198.51.100.7` (only 3 slow guesses) are not flagged. The rule ignores normal mistakes.

## How it works (simple)
1. **Read:** each log line is checked with a regular expression to find "Failed password", "Invalid user" and "Accepted password" lines.
2. **Collect:** every login event is saved with its time, username and source IP.
3. **Apply the rule:** for each IP, a sliding time window counts how many failures happened inside the last few minutes.
4. **Alert:** if the count reaches the limit, the IP is flagged. If that same IP then logs in successfully, it is marked critical.

## About the sample data
`sample_logs/auth_sample.log` is made-up data created by `generate_sample_log.py`, in the same format as a real Rocky Linux log. The attacker IPs come from ranges reserved for documentation, so they are not real machines. To test on real activity, make a few wrong-password SSH attempts against your own VM and run the tool on `/var/log/secure`.

## Limits and ideas to improve
- It reads syslog-style logs. Systems that only use journald need `journalctl -u sshd` output saved to a file first.
- Ideas: send an email alert, block flagged IPs automatically with `firewalld`, or send the same logs to Splunk or Wazuh for a bigger setup.
