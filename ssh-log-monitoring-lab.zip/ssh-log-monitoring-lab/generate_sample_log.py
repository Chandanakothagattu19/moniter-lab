#!/usr/bin/env python3
"""
Creates sample_logs/auth_sample.log: a made-up (synthetic) SSH log in the same format as
/var/log/secure on Rocky Linux, so the monitor can be tested without a real attack.
The attacker IPs come from ranges reserved for documentation, so they are not real machines.
"""
import random
from datetime import datetime, timedelta

random.seed(42)
start = datetime(2026, 11, 25, 9, 0, 0)
HOST = "rocky"
lines = []
pid = 2000


def add(when, msg):
    global pid
    pid += 1
    lines.append(f"{when:%b} {when.day:>2} {when:%H:%M:%S} {HOST} sshd[{pid}]: {msg}")


# 1) Normal logins from the office network
for i, (user, ip) in enumerate([("chandana", "192.168.1.10"), ("support", "192.168.1.22"), ("chandana", "192.168.1.10")]):
    t = start + timedelta(minutes=10 * i)
    add(t, f"Accepted password for {user} from {ip} port {50000 + i} ssh2")

# 2) A user mistypes a password twice, then logs in (not an attack)
t = start + timedelta(minutes=40)
add(t, "Failed password for support from 192.168.1.22 port 51000 ssh2")
add(t + timedelta(seconds=9), "Failed password for support from 192.168.1.22 port 51002 ssh2")
add(t + timedelta(seconds=20), "Accepted password for support from 192.168.1.22 port 51004 ssh2")

# 3) Brute force attack: 14 guesses in about 2 minutes, never succeeds
t = start + timedelta(hours=1)
for i, user in enumerate(["admin", "root", "test", "oracle", "ubuntu", "admin", "root",
                          "user", "guest", "postgres", "admin", "root", "pi", "test"]):
    when = t + timedelta(seconds=i * 9)
    if user in ("admin", "test", "oracle", "ubuntu", "user", "guest", "postgres", "pi"):
        add(when, f"Invalid user {user} from 203.0.113.45 port {40000 + i}")
        add(when, f"Failed password for invalid user {user} from 203.0.113.45 port {40000 + i} ssh2")
    else:
        add(when, f"Failed password for {user} from 203.0.113.45 port {40000 + i} ssh2")

# 4) Slow guesser: only 3 failures (below the alert limit)
t = start + timedelta(hours=1, minutes=30)
for i in range(3):
    add(t + timedelta(minutes=2 * i), f"Failed password for root from 198.51.100.7 port {41000 + i} ssh2")

# 5) Break-in: 7 failures, then a successful login from the same IP
t = start + timedelta(hours=2)
for i in range(7):
    add(t + timedelta(seconds=i * 6), f"Failed password for support from 203.0.113.99 port {42000 + i} ssh2")
add(t + timedelta(seconds=52), "Accepted password for support from 203.0.113.99 port 42010 ssh2")

lines.sort(key=lambda l: (datetime.strptime("2026 " + l[:15], "%Y %b %d %H:%M:%S")))
with open("sample_logs/auth_sample.log", "w") as handle:
    handle.write("\n".join(lines) + "\n")
print(f"Wrote {len(lines)} lines to sample_logs/auth_sample.log")
