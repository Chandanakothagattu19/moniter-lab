import os
import sys
import unittest
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ssh_monitor as m

YEAR = 2026


def ev(second, kind="failed", ip="203.0.113.5", user="admin"):
    return {"time": datetime(YEAR, 11, 25, 10, 0, second), "kind": kind, "user": user, "ip": ip}


class ParseTests(unittest.TestCase):
    def test_failed_password_line(self):
        line = "Nov 25 10:15:32 rocky sshd[1234]: Failed password for invalid user admin from 203.0.113.45 port 40222 ssh2"
        e = m.parse_line(line, YEAR)
        self.assertEqual((e["kind"], e["user"], e["ip"]), ("failed", "admin", "203.0.113.45"))

    def test_accepted_line(self):
        line = "Nov 25 10:16:00 rocky sshd[1235]: Accepted password for chandana from 192.168.1.10 port 50000 ssh2"
        self.assertEqual(m.parse_line(line, YEAR)["kind"], "accepted")

    def test_other_lines_are_ignored(self):
        self.assertIsNone(m.parse_line("Nov 25 10:00:00 rocky CRON[99]: session opened", YEAR))


class DetectionTests(unittest.TestCase):
    def test_five_fast_failures_are_flagged(self):
        events = [ev(s) for s in range(0, 50, 10)]
        self.assertIn("203.0.113.5", m.find_brute_force(events, 5, 5))

    def test_four_failures_are_not_flagged(self):
        events = [ev(s) for s in range(0, 40, 10)]
        self.assertEqual(m.find_brute_force(events, 5, 5), {})

    def test_slow_failures_are_not_flagged(self):
        events = [
            {"time": datetime(YEAR, 11, 25, 10, minute, 0), "kind": "failed", "user": "x", "ip": "203.0.113.5"}
            for minute in (0, 10, 20, 30, 40)
        ]
        self.assertEqual(m.find_brute_force(events, 5, 5), {})

    def test_success_after_failures_is_critical(self):
        events = [ev(s) for s in range(0, 50, 10)] + [ev(55, kind="accepted")]
        self.assertEqual(len(m.find_success_after_failures(events, 5, 5)), 1)

    def test_normal_login_is_not_critical(self):
        events = [ev(0), ev(10), ev(20, kind="accepted")]
        self.assertEqual(m.find_success_after_failures(events, 5, 5), [])


if __name__ == "__main__":
    unittest.main()
